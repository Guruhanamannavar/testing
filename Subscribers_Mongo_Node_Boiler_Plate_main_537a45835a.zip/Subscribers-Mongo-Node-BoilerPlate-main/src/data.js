const data = [
    {
      "name": "Jeread Krus",
      "subscribedChannel": "CNET"
    },
    {
      "name": "John Doe",
      "subscribedChannel": "freeCodeCamp.org"
    },
    {
      "name": "Lucifer",
      "subscribedChannel": "Sentex"
    }
  ]

module.exports = data;